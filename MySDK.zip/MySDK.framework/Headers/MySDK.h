//
//  MySDK.h
//  MySDK
//
//  Created by Vigneshkumar G on 13/02/19.
//  Copyright © 2019 viki. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MySDK.
FOUNDATION_EXPORT double MySDKVersionNumber;

//! Project version string for MySDK.
FOUNDATION_EXPORT const unsigned char MySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MySDK/PublicHeader.h>


